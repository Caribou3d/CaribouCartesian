This is a simple collection of batch scripts that simplify backing up and restoring firmware to Rambo controller boards.


RAMBO_RestoreToFactoryFirmware.cmd - This writes "Marlinth2.hex" firmware to the Rambo.

MiniRambo_RestoreToFactoryFirmware.cmd - This writes "MiniRamboUltimachineFW.hex" firmware to the MiniRambo.

BackupMyRamboFirmware.cmd - This reads the firmware off a Rambo and stores it in "MyFirmware_Backup.hex"

RestoreFromBackupMyRamboFirmware.cmd - This writes "MyFirmware_Backup.hex" firmware to the Rambo.